//set up the world real quick!...
gravity(0,9.82);

setBackground('assets/bg1.png');

gameWidth = 2048;
gameHeight = 683;

viewWidth = 640;
viewHeight = 480;


//NEED TO CHECK IF THIS FUNCTION ESISTS IN GAME LOOP!!
/*

if (typeof globalThis.myFunction === 'function') {
    // myFunction exists and is a function
    globalThis.myFunction();
} else {
    // myFunction does not exist or is not a function
    console.log('Function does not exist.');
}

*/
function viewPortFollow(){
	view = getPosition('dbox1')
	offsetX = 200;
	offsetY = 150;//if you are sensible, this woud be the height of the floor!
	x=view[0]-offsetX; //minus player width (or some other value that looks reasonable
	y=view[1]-viewHeight+offsetY; //-(viewport+player height!)
	if(x >= gameWidth-viewWidth){//right limit
		x=gameWidth-viewWidth;
	}
	if(x <= 0){//left limit
		x=0;
	};
	if(y <= -0){//top limit
		y= -0;
	};
	$('#canvas').css('transform', 'translate(' + -x + 'px, ' + -y + 'px)');
};



var density = 100;
var friction = 1;
var restitution = 0.5;

createDiv(
	'test',
	10, //Xpos
	10, //Ypos
	200, //Width
	40, //height
	0, //Radius
	null,//color
	'',//image
	'yellow',//foreground color
	'Arial, sans-serif',//Font Family
	28, //Font Size
	'Bold',//Font weight
	1,//z index
	'Score = 0'//text
);


//Insert game code below! :-)

staticBox(
	'box', //class
	'box0', //id
	200,	//x poisition
	442,	//y position
	400,		//width
	10,		//height
	-15,		//angle
	density,friction,restitution,
	false, //is sensor
	'assets/stone.png'); //asset


staticBox(
	'box', //class
	'box1', //id
	630,	//x poisition
	389,	//y position
	500,		//width
	10,		//height
	0,		//angle
	density,friction,restitution,
	false, //is sensor
	'assets/stone.png'); //asset
	
staticBox(
	'box', //class
	'box3', //id
	1200,	//x poisition
	480,	//y position
	700,		//width
	10,		//height
	15,		//angle
	density,friction,restitution,
	false, //is sensor
	'assets/stone.png'); //asset	

staticBox(
	'box', //class
	'box4', //id
	1800,	//x poisition
	570,	//y position
	500,		//width
	10,		//height
	0,		//angle
	density,friction,restitution,
	false, //is sensor
	'assets/stone.png'); //asset	


/*
simpleWeld(obj1,obj2)
revoluteJoint(obj1,obj2,speed,torque,enabled)
Ordering is important for z-index
*/	
	
dynamicBox(
	'dbox',
	'dbox1',
	200,//X
	350,//Y
	150,
	65,
	0,
	false,//must be false!
	10,0.5,0,
	'assets/carfin.png');
/*
dynamicBox(
	'dbox',
	'dbox2',
	230,//X
	330,//Y
	20,
	20,
	0,
	false,//must be false!
	0.1,0.5,10,
	null);	
simpleWeld('dbox1','dbox2');
*/
	
dynamicCircle(
	'circle',//class
	'circle1',//id
	155,//x position
	377,//y position
	35,//diameter
	0, //angle
	false, //turn off rolling
	1,friction,0,
	'assets/wheel.png'); //asset

dynamicCircle(
	'circle',//class
	'circle2',//id
	244,//x position
	376,//y position
	35,//diameter
	0, //angle
	false, //turn off rolling
	1,friction,0,
	'assets/wheel.png'); //asset


	
revoluteJoint('circle1','dbox1',0,0,false);
revoluteJoint('circle2','dbox1',0,0,false);	



accel = 0	
///set up controls
$(window).keydown(function(e){
	//console.log(e);
	if (e.keyCode == 37){
		//console.log('left');
		RevJoint0.m_enableMotor = true;
		RevJoint0.m_motorSpeed = accel;
		RevJoint0.m_maxMotorTorque=1000.00;
		accel ++;
	}
	if (e.keyCode == 39){
		//console.log('right')
		RevJoint0.m_enableMotor = true;
		RevJoint0.m_motorSpeed = accel;
		RevJoint0.m_maxMotorTorque=1000.00;
		accel--;
	}
	if (e.keyCode == 32){
		//console.log('space');
		accel = 0;
		RevJoint0.m_enableMotor = false;
		RevJoint0.m_motorSpeed = 0;
		RevJoint0.m_maxMotorTorque=0;
		circle1.m_angularVelocity = 0;
		circle2.m_angularVelocity = 0;
	}
});





















