//set up the world real quick!...
gravity(0,9.82);

setBackground('assets/bg1.png');

gameWidth = 2048;
gameHeight = 683;

viewWidth = 640;
viewHeight = 480;


//NEED TO CHECK IF THIS FUNCTION ESISTS IN GAME LOOP!!
/*

if (typeof globalThis.myFunction === 'function') {
    // myFunction exists and is a function
    globalThis.myFunction();
} else {
    // myFunction does not exist or is not a function
    console.log('Function does not exist.');
}

*/
function viewPortFollow(){
	view = getPosition('player')
	offsetX = 100;
	offsetY = 30;//if you are sensible, this woud be the height of the floor!
	x=view[0]-offsetX; //minus player width (or some other value that looks reasonable
	y=view[1]-viewHeight+offsetY; //-(viewport+player height!)
	if(x >= gameWidth-viewWidth){//right limit
		x=gameWidth-viewWidth;
	}
	if(x <= 0){//left limit
		x=0;
	};
	if(y <= -0){//top limit
		y= -0;
	};
	$('#canvas').css('transform', 'translate(' + -x + 'px, ' + -y + 'px)');
};



var density = 100;
var friction = 1;
var restitution = 0.5;

createDiv(
	'test',
	10, //Xpos
	10, //Ypos
	200, //Width
	40, //height
	0, //Radius
	null,//color
	'',//image
	'yellow',//foreground color
	'Arial, sans-serif',//Font Family
	28, //Font Size
	'Bold',//Font weight
	1,//z index
	'Score = 0'//text
);


//Insert game code below! :-)

staticBox('platform',    //object name
	'platform1', //object id
	gameWidth/2,		//X
	670,		//Y
	gameWidth,		//width
	20,			//height
	0,			//angle
	density,1,restitution,
	false, //is sensor
	null);		//asset

dynamicCircle('ball',//class
	'player',//id
	220,//x position
	20,//y position
	20,//diameter
	0, //angle
	false, //turn off rolling
	1,friction,restitution,
	null); //asset
	
staticBox(
	'box', //class
	'test1', //id
	350,	//x position
	650,	//y position
	40,		//width
	40,		//height
	0,		//angle
	density,friction,restitution,
	false, //is sensor
	null); //asset	
	
superCollider(
	'class', //collide by
	'ball', //objectA
	'box', //objectB
	'box', //object to destroy
	null, //function to run
);




///set up controls
$(window).keydown(function(e){
	//console.log(e);
	if (e.keyCode == 37){
		//console.log('left');
		shoveObject('player',-1,0);
	}
	if (e.keyCode == 39){
		//console.log('right')
		shoveObject('player',1,0);
	}
	if (e.keyCode == 32){
		//console.log('space');
		shoveObject('player',0,-5); //fire player vertically
	}
});

$(window).keyup(function(e){
	//console.log(e);
	if (e.keyCode == 37){
		//console.log('left');
		deadStop('player');
	}
	if (e.keyCode == 39){
		//console.log('right')
		deadStop('player');
	};
});