//setup walls and floors etc
//In here lets give id and class names that people are unlikely to use 
staticBox('7EBC600',//object name
	'7EBC601', //Floor
	gameWidth/2,		//X
	gameHeight,		//Y
	gameWidth,		//width
	1,			//height
	0,			//angle
	0,0,0,
	false, //is sensor
	null);		//asset
			
staticBox('7EBC600',
	'7EBC602',//ceiling
	gameWidth/2,
	0,
	gameWidth,
	1,
	0,
	0,0,0,
	false, //is sensor
	null);	//asset
		
staticBox('7EBC600',
	'7EBC603',//left wall
	1,
	gameHeight/2,
	1,
	gameHeight,
	0,
	0,0,0,
	false, //is sensor
	null); //asset

staticBox('7EBC600',
	'7EBC604',//right wall
	gameWidth,
	gameHeight/2,
	1,
	gameHeight,
	0,
	0,0,0,
	false, //is sensor
	null); //asset

//The canvas
$("#canvas").width(gameWidth);
$("#canvas").height(gameHeight);



//Check and see if we set varibales for viewport
if ((typeof viewWidth === 'undefined') || (typeof viewHeight === 'undefined')) {
    var viewWidth = gameWidth;
	var viewHeight = gameHeight;
};

$("#viewport").width(viewWidth+1);
$("#viewport").height(viewHeight+1);


//box2d canvas for debugging
$("#box2dCanvas").width(gameWidth);
$("#box2dCanvas").height(gameHeight);


