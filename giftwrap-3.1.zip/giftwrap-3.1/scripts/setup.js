//setup walls and floors etc
staticBox('wall',//object name
	'floor', //object ida
	gameWidth/2,		//X
	gameHeight,		//Y
	gameWidth,		//width
	1,			//height
	0,			//angle
	0,0,0,
	false, //is sensor
	null);		//asset
			
staticBox('wall',
	'ceiling',
	gameWidth/2,
	0,
	gameWidth,
	1,
	0,
	0,0,0,
	false, //is sensor
	null);	//asset
		
staticBox('wall',
	'leftwall',
	1,
	gameHeight/2,
	1,
	gameHeight,
	0,
	0,0,0,
	false, //is sensor
	null); //asset

staticBox('wall',
	'rightwall',
	gameWidth,
	gameHeight/2,
	1,
	gameHeight,
	0,
	0,0,0,
	false, //is sensor
	null); //asset

$("#score").width(gameWidth+1);

$("#wrapper").width(gameWidth+1);
$("#wrapper").height(gameHeight+1)

$("#canvas").width(gameWidth);
$("#canvas").height(gameHeight);

$("#box2dCanvas").width(gameWidth);
$("#box2dCanvas").height(gameHeight);