//set up the world real quick!...
gravity(0,9.82);

gameWidth = 1500;
gameHeight = 768;

var density = 100;
var friction = 1;
var restitution = 0.5;

createDiv(
	'test',
	10, //Xpos
	10, //Ypos
	200, //Width
	40, //height
	0, //Radius
	'',//color
	'',//image
	'yellow',//foreground color
	'Arial, sans-serif',//Font Family
	28, //Font Size
	'Bold',//Font weight
	1,//z index
	'Hello World!!'//text
);


//Insert game code below! :-)

dynamicCircle('ball',//class
	'player',//id
	100,//x position
	100,//y position
	30,//diameter
	0, //angle
	true, //turn off rolling
	1,10,restitution,
	null); //asset



///set up controls
$(window).keydown(function(e){
	//console.log(e);
	if (e.keyCode == 37){
		//console.log('left');
		shoveObject('player',-1,0);
	}
	if (e.keyCode == 39){
		//console.log('right')
		shoveObject('player',1,0);
	}
	if (e.keyCode == 32){
		//console.log('space');
		shoveObject('player',0,-7); //fire player vertically
	}
});

$(window).keyup(function(e){
	//console.log(e);
	if (e.keyCode == 37){
		//console.log('left');
		deadStop('player');
	}
	if (e.keyCode == 39){
		//console.log('right')
		deadStop('player');
	};
});